# Pose to Rest Pose

A Blender addon for applying the current pose as rest pose while preserving shape keys and drivers with a single click.

## Features

- **One-Click Operation**: Apply current pose as rest pose directly from the Pose menu
- **Shape Key Preservation**: Maintains all shape keys including values, slider ranges, mute states, and custom properties
- **Driver Support**: Preserves shape key drivers and automatically updates self-references
- **Multi-Mesh Support**: Handles multiple meshes affected by the same armature

## Installation
1. Open Blender's "Edit" → "Preferences" → "Get Extensions"
2. Open "Repositories" → click "+" → "Add Remote Repository"
3. Enter the URL: `https://kxn4t.github.io/blender-extensions/index.json`
4. Search for "Pose to Rest Pose" and install

## Usage

### Basic Usage
1. Select your armature and enter **Pose Mode**
2. Position your armature in the desired pose
3. Go to **Pose > Apply > Apply Current Pose as Rest Pose**

The addon will automatically:
- Detect all meshes with Armature modifiers targeting the selected armature, including those in other scenes
- Preserve all shape keys and their properties
- Apply the current pose to the armature's rest position
- Restore all modifiers and drivers

## Technical Details

### Shape Key Processing
This addon uses algorithms from [SKkeeper](https://github.com/smokejohn/SKkeeper) to:
- Create temporary copies of each shape key
- Apply the armature modifier with the current pose
- Transfer shape keys back to the base mesh
- Maintain all shape key properties and relationships

### Driver Handling
- Automatically detects existing drivers on shape keys
- Preserves driver expressions and variables
- Restores driver relationships, including self-references to shape key data

## Requirements
Blender 4.2.0 or higher

> **Note:** For Blender 3.6–4.1, please use [v0.3.0](https://github.com/kxn4t/pose-to-rest-pose/releases/tag/v0.3.0) (final legacy version).

- Meshes must have only one Armature modifier per target armature

## Limitations & Best Practices

### Modifier Order
For optimal results, ensure proper modifier order:
- ✅ **Recommended**: Armature Modifier → Other Deformation Modifiers
- ❌ **Not Recommended**: Deformation Modifiers → Armature Modifier

Deformation modifiers (Displace, Wave, Shrinkwrap, etc.) placed before the Armature modifier may cause vertex count mismatches during shape key transfer.
Modifiers that may change vertex count should also be handled with care.

### Shared Mesh Data
- Objects with shared (linked) mesh data are not supported. If multiple objects share the same mesh (e.g., created with Alt+D), you will be prompted to make them single-user first (Object > Relations > Make Single User > Object & Data).

### Scene Scope
- The addon processes all meshes across all scenes that reference the target armature, since `pose.armature_apply()` modifies the armature data block itself

### Not Preserved
The following data is **not** preserved by this addon:
- **Shape key animation data**: Keyframes, Actions, and NLA strips on shape keys are not transferred. Apply this addon before creating shape key animations.
- **Armature modifier custom properties**: Custom properties added to the Armature modifier itself will be lost. Standard modifier settings (preserve volume, vertex group, stack position, etc.) are restored.

## License

GPL v3 License (see LICENSE) - Free for personal and commercial use.

## Credits

This addon was created using shape key preservation algorithms from SKkeeper.

- **Shape Key Algorithms**: [SKkeeper](https://github.com/smokejohn/SKkeeper) by Johannes Rauch
- **License**: GPL v3
